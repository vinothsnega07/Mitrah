USE exercise2

GO

--1
SELECT *
FROM Task T
join Project P ON P.ProjectID=T.ProjectID

GO

--2
SELECT P.*,T.TaskName,T.StartDate,T.DueDate
FROM Project P
LEFT JOIN Task T ON P.ProjectID=T.ProjectID

GO

--3
SELECT t.*,P.ProjectName,P.StartDate,P.EndDate
FROM Task T
RIGHT JOIN Project P ON P.ProjectID=T.ProjectID

GO

select * from Project where ParentProjectId=1
--4
ALTER TABLE Project
ADD ParentProjectId INT NULL

UPDATE Project
SET ParentProjectID=4
WHERE ProjectID=5

SELECT Parent.ProjectID AS ParentProjectID,
Parent.ProjectName AS ParentProjectName,
Child.ProjectID AS ChildProjectID,
Child.ProjectName AS ChildProjectName
FROM Project Child
JOIN Project Parent ON  Parent.ProjectID= Child.ParentProjectId


GO

--5
SELECT GETDATE() AS 'CurrentDateTime'
SELECT CURRENT_TIMESTAMP AS 'CurrentTimeStamp'

GO

--6
SELECT ProjectName,
YEAR (StartDate) AS Current_year,
MONTH (StartDate) AS Current_mONth,
DAY(EndDate) AS end_Day
FROM Project;

GO

--7
SELECT ProjectName,
DATEDIFF (DAY,StartDate,EndDate) AS DuratiONDays
FROM Project

GO

--8
SELECT ProjectName,CONVERT(varchar,StartDate,23) AS Formatted_Date
FROM Project

GO

--9
SELECT P.ProjectName,T.TASkName
FROM Project P
cross apply(
SELECT TASkName
FROM TASk T
where P.ProjectID=T.ProjectID
)T;



