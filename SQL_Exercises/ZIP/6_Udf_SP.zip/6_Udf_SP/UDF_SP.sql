Use exercise2;

GO

CREATE OR ALTER PROCEDURE TaskSP
	@Action VARCHAR(20),
	@TaskID INT =null,
	@TaskName VARCHAR(200)=null,
	@Description VARCHAR(200)=null,
	@StartDate Date=null,
	@DueDate Date=null,
	@Priority VARCHAR(200)=null,
	@Status VARCHAR(200)=null,
	@ProjectID INT=null
	AS
	BEGIN
		
		--Insert
			IF @Action = 'INSERT'	
			BEGIN
				INSERT INTO Task (TaskName,Description,StartDate,DueDate,Priority,Status,ProjectID) 
				VALUES (@TaskName,@Description,@StartDate,@DueDate,@Priority,@Status,@ProjectID);
			END


		--Update
			IF @Action='UPDATE'
			BEGIN
				Update Task 
				Set TaskName=@TaskName,
				Description=@Description,
				StartDate=@StartDate,
				DueDate=@DueDate,
				[Priority]=@Priority,
				Status=@Status,
				ProjectID=@ProjectID
				WHERE TaskID=@TaskID
			END

		--Delete 
			IF @Action='DELETE'
			BEGIN
				DELETE FROM Task
				WHERE TaskID=@TaskID
			END

		--SELECT
			IF @Action='SELECT'
			BEGIN
				SELECT * FROM TASK
			END
			
	END

	--Insert
	EXEC TaskSP
	@Action='INSERT',
	@TaskName='Alpha Testing',
	@Description='Conducting Alpha Testing For Mobile App',
	@StartDate='2024-06-05',
	@DueDate='2024-07-05',
	@Priority='High',
	@Status='Pending',
	@ProjectID=2

	--Update
	EXEC TaskSP
	@Action='Update',
	@TaskName='Alpha',
	@Description='Conduct alpha testing',
	@StartDate='2024-07-05',
	@DueDate='2024-08-05',
	@Priority='Medium',
	@Status='Completed',
	@ProjectID=3,
	@TaskID=12


	--Delete
	EXEC TaskSP
	@Action='Delete',
	@TaskID=13

	--Select
	EXEC TaskSP
	@Action='SELECT'
	
--Function
CREATE FUNCTION taskFunction ()
RETURNS TABLE
AS
RETURN(
    SELECT * FROM Task
);

SELECT * FROM taskFunction();